# Mastery with SQL - A hands-on practical course for learning modern SQL
This page lists updates made to the course since launch and any known errata/corrections still to be made.

## Course Update History

### 3rd October, 2019 
- Added new chapter "Query performance and indexing"

### 27th June, 2019 
- Fixed error in Exercise 4.7 solution

### 26th June, 2019 
- Fixed error in Exercise 6.8 solution

### 24th June, 2019 
- Added entire new chapter "Views and functions"

### 7th June, 2019 
- Minor correction in Chapter 5 "Number data types" video
- Minor correction in Chapter 5 "Date and time data types" video

### 3rd June, 2019
- Course launch


## Errata
None.
